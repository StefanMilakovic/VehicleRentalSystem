package org.unibl.etfbl.ip.vehiclerentalsystem.dto;

/*
public abstract class VehicleDTO {
    private Integer id;
    private Double purchasePrice;
    private String model;
    private String photoUrl;
    private Integer manufacturerId;

    // Getteri i setteri
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Double getPurchasePrice() { return purchasePrice; }
    public void setPurchasePrice(Double purchasePrice) { this.purchasePrice = purchasePrice; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }

    public Integer getManufacturerId() { return manufacturerId; }
    public void setManufacturerId(Integer manufacturerId) { this.manufacturerId = manufacturerId; }
}

 */
