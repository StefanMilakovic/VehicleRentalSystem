package org.unibl.etfbl.ip.vehiclerentalsystem.dto;
/*
public class ElectricBicycleDTO extends VehicleDTO {
    private Integer autonomy;

    public Integer getAutonomy() { return autonomy; }
    public void setAutonomy(Integer autonomy) { this.autonomy = autonomy; }
}

 */
