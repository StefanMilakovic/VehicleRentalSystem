package org.unibl.etfbl.ip.vehiclerentalsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleRentalSystemApplicationTests
{

    @Test
    void contextLoads()
    {
    }

}
